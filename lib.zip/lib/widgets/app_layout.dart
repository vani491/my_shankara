import 'package:flutter/material.dart';

class AppLayout extends StatefulWidget {
  final String title;
  final Widget body;
  final List<Widget>? actions;
  final Widget? drawer;
  final bool showMenuButton;
  final VoidCallback? onMenuPressed;

  // Static image background (kept for backwards-compat)
  final String? backgroundImage;
  final double backgroundOpacity;

  // Video background — takes priority over backgroundImage when set
  final String? backgroundVideo;
  final double backgroundVideoOpacity;

  const AppLayout({
    Key? key,
    required this.title,
    required this.body,
    this.actions,
    this.drawer,
    this.showMenuButton = true,
    this.onMenuPressed,
    this.backgroundImage,
    this.backgroundOpacity = 1.0,
    this.backgroundVideo,
    this.backgroundVideoOpacity = 1.0,
  }) : super(key: key);

  @override
  State<AppLayout> createState() => _AppLayoutState();
}

class _AppLayoutState extends State<AppLayout> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void didUpdateWidget(AppLayout oldWidget) {
    super.didUpdateWidget(oldWidget);
  }


  @override
  void dispose() {
    super.dispose();
  }

  // ── Background layer ───────────────────────────────────────────────────────

  Widget _buildBackground() {

    // 2. Static image background (legacy)
    if (widget.backgroundImage != null) {
      return Positioned.fill(
        child: Image.asset(
          widget.backgroundImage!,
          fit: BoxFit.cover,
          opacity: AlwaysStoppedAnimation(widget.backgroundOpacity),
        ),
      );
    }

    return const SizedBox.shrink();
  }

  // ── Build ──────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final hasBackground =
        widget.backgroundVideo != null || widget.backgroundImage != null;

    return Scaffold(
      // Extend body (and video) behind the AppBar so the video fills the screen
      extendBodyBehindAppBar: hasBackground,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        leading: widget.showMenuButton
            ? Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: widget.onMenuPressed ??
                    () => Scaffold.of(context).openDrawer(),
            tooltip: 'Menu',
          ),
        )
            : null,
        title: Text(widget.title),
        actions: widget.actions,
      ),
      drawer: widget.drawer,
      body: hasBackground
          ? Stack(
        fit: StackFit.expand,
        children: [
          // Video / image layer — rendered first (bottom)
          _buildBackground(),
          // Content layer on top
          widget.body,
        ],
      )
          : widget.body,
    );
  }
}